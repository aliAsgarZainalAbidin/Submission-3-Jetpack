package com.example.sub2jetpack.ui.movie;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.sub2jetpack.R;
import com.example.sub2jetpack.data.local.entity.MovieEntity;
import com.example.sub2jetpack.ui.detail.DetailActivity;
import java.util.ArrayList;
import java.util.List;

public class MovieUpcomingAdapter extends RecyclerView.Adapter<MovieUpcomingAdapter.ViewHolder> {

    private final List<MovieEntity> list = new ArrayList<>();

    public void setList(List<MovieEntity> list) {
        if (list == null) return;
        this.list.clear();
        this.list.addAll(list);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_upcoming,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieEntity movieEntity = list.get(position);
        holder.bind(movieEntity);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView imageView;
        final ConstraintLayout constraintLayout;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_item_upcoming);
            constraintLayout = itemView.findViewById(R.id.constraint_grid_container);
        }

        void bind(MovieEntity items){
            Glide.with(itemView.getContext())
                    .load(items.getPosterPath())
                    .into(imageView);

            constraintLayout.setOnClickListener(v -> {
                Intent intent = new Intent(itemView.getContext(), DetailActivity.class);
                intent.putExtra(DetailActivity.ITEM_CODE,  DetailActivity.MOVIE);
                intent.putExtra(DetailActivity.IMAGE_BACKDROP, items.getBackdropPath());
                intent.putExtra(DetailActivity.TITLE_ITEM, items.getTitle());
                intent.putExtra(DetailActivity.DATE_ITEM, items.getReleaseDate());
                intent.putExtra(DetailActivity.POPULARITY, items.getPopularity());
                intent.putExtra(DetailActivity.RATE, items.getVoteAverage());
                intent.putExtra(DetailActivity.REVIEWERS, items.getVoteCount());
                intent.putExtra(DetailActivity.LANGUAGE, items.getOriginalLanguage());
                intent.putExtra(DetailActivity.IMAGE_POSTER, items.getPosterPath());
                intent.putExtra(DetailActivity.ORIGINAL_TITLE, items.getOriginalTitle());
                intent.putExtra(DetailActivity.ADULT, items.isAdult());
                intent.putExtra(DetailActivity.VIDEO, items.isVideo());
                intent.putExtra(DetailActivity.OVERVIEW, items.getOverview());

                itemView.getContext().startActivity(intent);
            });
        }
    }
}
