package com.example.sub2jetpack.ui.tvShow;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sub2jetpack.R;
import com.example.sub2jetpack.data.local.entity.TvEntity;
import com.example.sub2jetpack.ui.detail.DetailActivity;

import java.util.ArrayList;
import java.util.List;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.ViewHolder> {

    private List<TvEntity> list = new ArrayList<>();

    public void setList(List<TvEntity> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_cardview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TvEntity dataTvShow = list.get(position);
        holder.bind(dataTvShow);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        final ImageView imageView;
        final CardView cardView;
        ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_item_grid);
            cardView = itemView.findViewById(R.id.cardview_grid_container);
        }

        void bind(TvEntity data){
            Glide.with(itemView.getContext())
                    .load(data.getPosterPath())
                    .into(imageView);
            cardView.setOnClickListener(v -> {
                Intent intent = new Intent(itemView.getContext(), DetailActivity.class);
                intent.putExtra(DetailActivity.ITEM_CODE, DetailActivity.TV_SHOW);
                intent.putExtra(DetailActivity.ORIGINAL_TITLE, data.getOriginalName());
                intent.putExtra(DetailActivity.TITLE_ITEM, data.getName());
                intent.putExtra(DetailActivity.POPULARITY, data.getPopularity());
                intent.putExtra(DetailActivity.REVIEWERS, data.getVoteCount());
                intent.putExtra(DetailActivity.DATE_ITEM, data.getFirstAirDate());
                intent.putExtra(DetailActivity.IMAGE_BACKDROP, data.getBackdropPath());
                intent.putExtra(DetailActivity.LANGUAGE, data.getOriginalLanguage());
                intent.putExtra(DetailActivity.OVERVIEW, data.getOverview());
                intent.putExtra(DetailActivity.IMAGE_POSTER, data.getPosterPath());
                intent.putExtra(DetailActivity.RATE, data.getVoteAverage());

                itemView.getContext().startActivity(intent);
            });
        }
    }
}
