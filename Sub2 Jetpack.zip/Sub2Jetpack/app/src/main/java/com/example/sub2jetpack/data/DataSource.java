package com.example.sub2jetpack.data;

import androidx.lifecycle.LiveData;

import com.example.sub2jetpack.data.local.entity.MovieEntity;
import com.example.sub2jetpack.data.local.entity.TvEntity;

import java.util.List;

interface DataSource {
    LiveData<List<MovieEntity>> getAllMoviesUpcoming();
    LiveData<List<MovieEntity>> getAllMoviesPlaying();
    LiveData<List<TvEntity>> getAllTvShows();
}
