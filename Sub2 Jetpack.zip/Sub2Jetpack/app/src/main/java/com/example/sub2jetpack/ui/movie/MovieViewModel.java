package com.example.sub2jetpack.ui.movie;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.sub2jetpack.data.Repository;
import com.example.sub2jetpack.data.local.entity.MovieEntity;

import java.util.List;

public class MovieViewModel extends ViewModel {
    private final Repository repository;

    public MovieViewModel(Repository repository) {
        this.repository = repository;
    }

    public LiveData<List<MovieEntity>> getMoviesUpcoming(){
        return repository.getAllMoviesUpcoming();
    }

    public LiveData<List<MovieEntity>> getMoviesPlaying(){
        return repository.getAllMoviesPlaying();
    }
}
