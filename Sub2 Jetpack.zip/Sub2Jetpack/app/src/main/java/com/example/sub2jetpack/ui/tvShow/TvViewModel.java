package com.example.sub2jetpack.ui.tvShow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.sub2jetpack.data.Repository;
import com.example.sub2jetpack.data.local.entity.TvEntity;

import java.util.List;

public class TvViewModel extends ViewModel {
    private final Repository repository;

    public TvViewModel(Repository repository) {
        this.repository = repository;
    }

    public LiveData<List<TvEntity>> getAllTvShow(){
        return repository.getAllTvShows();
    }
}
