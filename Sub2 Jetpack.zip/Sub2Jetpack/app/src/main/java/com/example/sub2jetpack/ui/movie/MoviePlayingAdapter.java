package com.example.sub2jetpack.ui.movie;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sub2jetpack.R;
import com.example.sub2jetpack.data.local.entity.MovieEntity;
import com.example.sub2jetpack.ui.detail.DetailActivity;

import java.util.ArrayList;
import java.util.List;

public class MoviePlayingAdapter extends RecyclerView.Adapter<MoviePlayingAdapter.ViewHolder> {

    private List<MovieEntity> list = new ArrayList<>();

    public void setList(List<MovieEntity> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieEntity movie = list.get(position);
        holder.bind(movie);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        final ImageView imageView;
        final TextView tvTitle;
        final ConstraintLayout constraintLayout;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_item);
            tvTitle = itemView.findViewById(R.id.tv_title);
            constraintLayout = itemView.findViewById(R.id.cl_items);
        }

        void bind(MovieEntity data){
            tvTitle.setText(data.getTitle());
            Glide.with(itemView.getContext())
                    .load(data.getPosterPath())
                    .into(imageView);

            constraintLayout.setOnClickListener(v -> {
                Intent intent = new Intent(itemView.getContext(), DetailActivity.class);
                intent.putExtra(DetailActivity.ITEM_CODE,  DetailActivity.MOVIE);
                intent.putExtra(DetailActivity.IMAGE_BACKDROP, data.getBackdropPath());
                intent.putExtra(DetailActivity.TITLE_ITEM, data.getTitle());
                intent.putExtra(DetailActivity.DATE_ITEM, data.getReleaseDate());
                intent.putExtra(DetailActivity.POPULARITY, data.getPopularity());
                intent.putExtra(DetailActivity.RATE, data.getVoteAverage());
                intent.putExtra(DetailActivity.REVIEWERS, data.getVoteCount());
                intent.putExtra(DetailActivity.LANGUAGE, data.getOriginalLanguage());
                intent.putExtra(DetailActivity.IMAGE_POSTER, data.getPosterPath());
                intent.putExtra(DetailActivity.ORIGINAL_TITLE, data.getOriginalTitle());
                intent.putExtra(DetailActivity.ADULT, data.isAdult());
                intent.putExtra(DetailActivity.VIDEO, data.isVideo());
                intent.putExtra(DetailActivity.OVERVIEW, data.getOverview());

                itemView.getContext().startActivity(intent);
            });
        }
    }

}
