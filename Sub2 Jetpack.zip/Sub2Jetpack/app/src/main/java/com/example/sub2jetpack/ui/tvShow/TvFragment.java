package com.example.sub2jetpack.ui.tvShow;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sub2jetpack.R;
import com.example.sub2jetpack.viewmodel.ViewModelFactory;

/**
 * A simple {@link Fragment} subclass.
 */
public class TvFragment extends Fragment {

    private RecyclerView rvTvShow;

    public TvFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tv, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvTvShow = view.findViewById(R.id.rv_tv_show);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getActivity()!=null){
            ViewModelFactory viewModelFactory = ViewModelFactory.getINSTANCE();
//            TvViewModel tvViewModel = new ViewModelProvider(this, viewModelFactory).get(TvViewModel.class);
            TvViewModel tvViewModel = new ViewModelProvider(this,viewModelFactory).get(TvViewModel.class);

            TvShowAdapter tvShowAdapter = new TvShowAdapter();
            tvViewModel.getAllTvShow().observe(this,tvEntities -> {
                tvShowAdapter.setList(tvEntities);
                tvShowAdapter.notifyDataSetChanged();
            });

            rvTvShow.setLayoutManager(new GridLayoutManager(getContext(),3));
            rvTvShow.setHasFixedSize(true);
            rvTvShow.setAdapter(tvShowAdapter);
        }
    }
}
