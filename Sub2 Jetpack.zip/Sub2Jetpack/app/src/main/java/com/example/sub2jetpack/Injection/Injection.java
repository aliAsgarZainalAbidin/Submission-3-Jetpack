package com.example.sub2jetpack.Injection;

import com.example.sub2jetpack.data.Repository;
import com.example.sub2jetpack.data.remote.RemoteDataSource;
import com.example.sub2jetpack.utils.JsonHelper;

public class Injection {
    public static Repository provideRepository(){
        RemoteDataSource remoteDataSource = RemoteDataSource.getINSTANCE(new JsonHelper());

        return Repository.getInstance(remoteDataSource);
    }
}
