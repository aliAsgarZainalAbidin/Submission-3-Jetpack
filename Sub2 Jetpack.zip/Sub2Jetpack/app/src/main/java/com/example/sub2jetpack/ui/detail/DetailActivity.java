package com.example.sub2jetpack.ui.detail;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.sub2jetpack.R;

public class DetailActivity extends AppCompatActivity {

    public static final String ITEM_CODE = "item_code";
    public static final String MOVIE = "movie";
    public static final String TV_SHOW = "tv_show";
    public static final String IMAGE_BACKDROP = "image_backdrop";
    public static final String TITLE_ITEM = "title_item";
    public static final String DATE_ITEM = "date_item";
    public static final String POPULARITY = "popularity";
    public static final String RATE = "rate";
    public static final String REVIEWERS = "reviewers";
    public static final String LANGUAGE = "language";
    public static final String IMAGE_POSTER = "image_poster";
    public static final String ORIGINAL_TITLE = "original_title";
    public static final String ADULT = "adult";
    public static final String VIDEO = "video";
    public static final String OVERVIEW = "overview";

    private ImageView imageViewBackdrop;
    private TextView textTitleItem;
    private TextView textDateItem;
    private TextView textPopularity;
    private TextView textRate;
    private TextView textReviewers;
    private TextView textLanguage;
    private ImageView imageViewPoster;
    private TextView textOriginalTitle;
    private TextView textDetailTitle;
    private TextView textAdult;
    private TextView textVideo;
    private TextView textOverview;
    private TextView textTitleAdult;
    private TextView textTitleDot3;
    private TextView textTitleDot4;
    private TextView textTitleVideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        imageViewBackdrop = findViewById(R.id.image_detail_backdrop);
        textTitleItem = findViewById(R.id.text_detail_title_item);
        textDateItem = findViewById(R.id.text_detail_date_item);
        textPopularity = findViewById(R.id.text_detail_popularity_value);
        textRate = findViewById(R.id.text_detail_rate_value);
        textReviewers = findViewById(R.id.text_detail_reviewers);
        textLanguage = findViewById(R.id.text_detail_language);
        imageViewPoster = findViewById(R.id.image_detail_poster);
        textOriginalTitle = findViewById(R.id.text_detail_original_title);
        textDetailTitle = findViewById(R.id.text_detail_title);
        textAdult = findViewById(R.id.text_detail_adult);
        textVideo = findViewById(R.id.text_detail_video);
        textTitleAdult = findViewById(R.id.text_detail_title_adult);
        textTitleDot3 = findViewById(R.id.text_detail_double_dot3);
        textTitleDot4 = findViewById(R.id.text_detail_double_dot4);
        textTitleVideo = findViewById(R.id.text_detail_title_video);
        textOverview = findViewById(R.id.text_detail_overview_item);

        String imageBackdrop = null;
        String title = null;
        String date = null;
        String popularity = null;
        String rate = null;
        String reviewers = null;
        String language = null;
        String imagePoster = null;
        String originalTitle = null;
        String adult = null;
        String video = null;
        String overview = null;
        String itemCode = getIntent().getStringExtra(ITEM_CODE);

        if (itemCode.equals(MOVIE)) {
            imageBackdrop = getIntent().getStringExtra(IMAGE_BACKDROP);
            title = getIntent().getStringExtra(TITLE_ITEM);
            date = getIntent().getStringExtra(DATE_ITEM);
            popularity = String.valueOf(getIntent().getLongExtra(POPULARITY, -1));
            rate = String.valueOf(getIntent().getFloatExtra(RATE, 0));
            reviewers = String.valueOf(getIntent().getIntExtra(REVIEWERS, 0));
            language = getIntent().getStringExtra(LANGUAGE);
            imagePoster = getIntent().getStringExtra(IMAGE_POSTER);
            originalTitle = getIntent().getStringExtra(ORIGINAL_TITLE);
            adult = getIntent().getBooleanExtra(ADULT, false) ? "YES" : "NO";
            video = getIntent().getBooleanExtra(VIDEO, false) ? "YES" : "NO";
            overview = getIntent().getStringExtra(OVERVIEW);
        } else if (itemCode.equals(TV_SHOW)) {
            originalTitle = getIntent().getStringExtra(ORIGINAL_TITLE);
            title = getIntent().getStringExtra(TITLE_ITEM);
            popularity = String.valueOf(getIntent().getLongExtra(POPULARITY, -1));
            reviewers = String.valueOf(getIntent().getIntExtra(REVIEWERS, -1));
            date = getIntent().getStringExtra(DATE_ITEM);
            imageBackdrop = getIntent().getStringExtra(IMAGE_BACKDROP);
            language = getIntent().getStringExtra(LANGUAGE);
            overview = getIntent().getStringExtra(OVERVIEW);
            imagePoster = getIntent().getStringExtra(IMAGE_POSTER);
            rate = String.valueOf(getIntent().getFloatExtra(RATE, 0));
            setViewGone();
        }
        reviewers = reviewers + getResources().getString(R.string.reviewers_example);

        Glide.with(getApplicationContext())
                .load(imageBackdrop)
                .into(imageViewBackdrop);
        textTitleItem.setText(title);
        textDateItem.setText(date);
        textPopularity.setText(popularity);
        textRate.setText(rate);
        textReviewers.setText(reviewers);
        textLanguage.setText(language);
        Glide.with(getApplicationContext())
                .load(imagePoster)
                .into(imageViewPoster);
        textOriginalTitle.setText(originalTitle);
        textDetailTitle.setText(title);
        textAdult.setText(adult);
        textVideo.setText(video);
        textOverview.setText(overview);
    }

    private void setViewGone() {
        textTitleAdult.setVisibility(View.GONE);
        textTitleVideo.setVisibility(View.GONE);
        textTitleDot4.setVisibility(View.GONE);
        textTitleDot3.setVisibility(View.GONE);
    }
}
